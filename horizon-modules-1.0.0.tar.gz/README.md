# Horizon ADC Modules Collection

This collection provides modules for managing Horizon ADC devices.
