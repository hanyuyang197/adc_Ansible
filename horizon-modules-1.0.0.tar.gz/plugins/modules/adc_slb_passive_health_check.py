#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys

# ADC API响应解析函数


def slb_passive_health_check_add(module):
    """添加被动健康检查"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.add" % (ip, authkey)

    # 构造请求数据 - 只包含非None的参数
    healthcheck_data = {}
    optional_params = ['name', 'type', 'interval', 'timeout', 'retry', 'port', 'send', 'receive']

    for param in optional_params:
        if module.params.get(param) is not None:
            healthcheck_data[param] = module.params[param]

    # 转换为JSON格式
    post_data = json.dumps(healthcheck_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="添加被动健康检查请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "添加被动健康检查", True, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def slb_passive_health_check_list(module):
    """获取被动健康检查列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.list" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取被动健康检查列表失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取被动健康检查列表", False, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def slb_passive_health_check_get(module):
    """获取被动健康检查详情"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.get" % (ip, authkey)

    # 构造请求数据 - 只包含非None的参数
    healthcheck_data = {}
    optional_params = ['name']

    for param in optional_params:
        if module.params.get(param) is not None:
            healthcheck_data[param] = module.params[param]

    # 转换为JSON格式
    post_data = json.dumps(healthcheck_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取被动健康检查详情请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取被动健康检查详情", False, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def slb_passive_health_check_edit(module):
    """编辑被动健康检查"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.edit" % (ip, authkey)

    # 构造请求数据 - 只包含非None的参数
    healthcheck_data = {}
    optional_params = ['name', 'type', 'interval', 'timeout', 'retry', 'port', 'send', 'receive']

    for param in optional_params:
        if module.params.get(param) is not None:
            healthcheck_data[param] = module.params[param]

    # 转换为JSON格式
    post_data = json.dumps(healthcheck_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="编辑被动健康检查请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "编辑被动健康检查", True, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def slb_passive_health_check_del(module):
    """删除被动健康检查"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params.get('name')

    # 检查必需参数
    if not name:
        module.fail_json(msg="删除被动健康检查需要提供name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.del" % (ip, authkey)

    # 构造请求数据
    healthcheck_data = {
        "name": name
    }

    # 转换为JSON格式
    post_data = json.dumps(healthcheck_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="删除被动健康检查请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "删除被动健康检查", True, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def slb_passive_health_check_list_withcommon(module):
    """获取被动健康检查列表（包含common和本分区）"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.passive-health-check.list.withcommon" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取被动健康检查列表失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取被动健康检查列表", False, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def main():
    """主函数"""
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True),
        name=dict(type='str', required=False),
        type=dict(type='str', required=False),
        interval=dict(type='int', required=False),
        timeout=dict(type='int', required=False),
        retry=dict(type='int', required=False),
        port=dict(type='int', required=False),
        send=dict(type='str', required=False),
        receive=dict(type='str', required=False)
    )

    # 创建模块
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # 根据action参数调用相应的函数
    action = module.params.get('action')

    if action == 'slb_passive_health_check_add':
        slb_passive_health_check_add(module)
    elif action == 'slb_passive_health_check_list':
        slb_passive_health_check_list(module)
    elif action == 'slb_passive_health_check_list_withcommon':
        slb_passive_health_check_list_withcommon(module)
    elif action == 'slb_passive_health_check_get':
        slb_passive_health_check_get(module)
    elif action == 'slb_passive_health_check_edit':
        slb_passive_health_check_edit(module)
    elif action == 'slb_passive_health_check_del':
        slb_passive_health_check_del(module)


if __name__ == '__main__':
    main()