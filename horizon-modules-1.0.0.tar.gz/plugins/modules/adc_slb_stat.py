#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys

# ADC API响应解析函数


def adc_slb_node_stat_list(module):
    """获取节点统计列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.node.stat.list" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 对于获取列表操作，直接返回响应数据，不判断success
        if response_data:
            try:
                parsed_data = json.loads(response_data)
                # 检查是否有错误信息
                if 'errmsg' in parsed_data and parsed_data['errmsg']:
                    module.fail_json(msg="获取节点统计列表失败", response=parsed_data)
                else:
                    module.exit_json(changed=False, node_stats=parsed_data)
            except Exception as e:
                module.fail_json(msg="解析响应失败: %s" % str(e))
        else:
            module.fail_json(msg="未收到有效响应")

    except Exception as e:
        module.fail_json(msg="获取节点统计列表失败: %s" % str(e))


def adc_slb_node_stat_get(module):
    """获取节点统计详情"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params.get('name')

    # 检查必需参数
    if not name:
        module.fail_json(msg="获取节点统计详情需要提供name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.node.stat.get" % (ip, authkey)

    # 构造请求数据
    stat_data = {
        "name": name
    }

    # 转换为JSON格式
    post_data = json.dumps(stat_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取节点统计详情请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取节点统计详情", False, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def adc_slb_node_stat_clear(module):
    """清除节点统计"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.node.stat.clear" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="清除节点统计请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "清除节点统计", True, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def adc_slb_pool_stat_list(module):
    """获取服务池统计列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.pool.stat.list" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 对于获取列表操作，直接返回响应数据，不判断success
        if response_data:
            try:
                parsed_data = json.loads(response_data)
                # 检查是否有错误信息
                if 'errmsg' in parsed_data and parsed_data['errmsg']:
                    module.fail_json(msg="获取服务池统计列表失败", response=parsed_data)
                else:
                    module.exit_json(changed=False, pool_stats=parsed_data)
            except Exception as e:
                module.fail_json(msg="解析响应失败: %s" % str(e))
        else:
            module.fail_json(msg="未收到有效响应")

    except Exception as e:
        module.fail_json(msg="获取服务池统计列表失败: %s" % str(e))


def adc_slb_pool_stat_get(module):
    """获取服务池统计详情"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params.get('name')

    # 检查必需参数
    if not name:
        module.fail_json(msg="获取服务池统计详情需要提供name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.pool.stat.get" % (ip, authkey)

    # 构造请求数据
    stat_data = {
        "name": name
    }

    # 转换为JSON格式
    post_data = json.dumps(stat_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取服务池统计详情请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取服务池统计详情", False, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def adc_slb_pool_stat_clear(module):
    """清除服务池统计"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.pool.stat.clear" % (ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="清除服务池统计请求失败: %s" % str(e))

    # 使用通用响应解析函数 - 只检查errmsg/errcode，不检查status
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "清除服务池统计", True, check_status=False)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")





def adc_slb_session_clear(module):
    """清除SLB会话"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    
    # 可选参数：可以指定特定的会话类型或范围
    session_type = module.params.get('session_type')
    va_name = module.params.get('va_name')

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.session.clear" % (ip, authkey)

    # 构造请求数据
    session_data = {
        "ip": ip,
        "authkey": authkey
    }

    # 添加可选参数
    if session_type:
        session_data['session_type'] = session_type
    if va_name:
        session_data['va_name'] = va_name

    # 转换为JSON格式
    post_data = json.dumps(session_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=post_data.encode('utf-8'), method='POST')
            req.add_header('Content-Type', 'application/json')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data)
            req.add_header('Content-Type', 'application/json')
            req.get_method = lambda: 'POST'
            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 使用通用响应解析函数
        if response_data:
            success, result_dict = format_adc_response_for_ansible(
                response_data, "清除SLB会话", True)
            if success:
                module.exit_json(**result_dict)
            else:
                module.fail_json(**result_dict)
        else:
            module.fail_json(msg="未收到有效响应")

    except Exception as e:
        module.fail_json(msg="清除SLB会话请求失败: %s" % str(e))


def main():
    """主函数"""
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'slb_node_stat_list', 'slb_node_stat_get', 'slb_node_stat_clear',
            'slb_pool_stat_list', 'slb_pool_stat_get', 'slb_pool_stat_clear',
            'slb_session_clear'
        ]),
        name=dict(type='str', required=False),
        session_type=dict(type='str', required=False),
        va_name=dict(type='str', required=False)
    )

    # 创建模块
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # 根据action参数调用相应的函数
    action = module.params.get('action')

    if action == 'slb_node_stat_list':
        adc_slb_node_stat_list(module)
    elif action == 'slb_node_stat_get':
        adc_slb_node_stat_get(module)
    elif action == 'slb_node_stat_clear':
        adc_slb_node_stat_clear(module)
    elif action == 'slb_pool_stat_list':
        adc_slb_pool_stat_list(module)
    elif action == 'slb_pool_stat_get':
        adc_slb_pool_stat_get(module)
    elif action == 'slb_pool_stat_clear':
        adc_slb_pool_stat_clear(module)
    elif action == 'slb_session_clear':
        adc_slb_session_clear(module)


if __name__ == '__main__':
    main()