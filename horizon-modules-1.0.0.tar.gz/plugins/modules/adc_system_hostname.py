#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys

# ADC API响应解析函数


def system_hostname_set(module):
    """设置系统主机名"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    hostname = module.params['hostname']

    # 检查必需参数
    if not hostname:
        module.fail_json(msg="设置系统主机名需要提供hostname参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.hostname.set" % (
        ip, authkey)

    # 构造主机名数据
    hostname_data = {
        "hostname": hostname
    }

    # 转换为JSON格式
    post_data = json.dumps(hostname_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="设置系统主机名失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "设置系统主机名", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_host_ipv4_get(module):
    """获取主机名IPv4地址"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2/?authkey=%s&action=system.host.ipv4.get" % (
        ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取主机名IPv4地址失败: %s" % str(e))

    # 对于获取操作，直接返回响应数据
    if response_data:
        try:
            parsed_data = json.loads(response_data)
            # 检查是否有错误信息
            if 'errmsg' in parsed_data and parsed_data['errmsg']:
                module.fail_json(msg="获取主机名IPv4地址失败", response=parsed_data)
            else:
                module.exit_json(changed=False, host_ipv4=parsed_data)
        except Exception as e:
            module.fail_json(msg="解析响应失败: %s" % str(e))
    else:
        module.fail_json(msg="未收到有效响应")


def system_host_ipv4_set(module):
    """设置主机名IPv4地址"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    host_ipv4_address = module.params['host_ipv4_address']

    # 检查必需参数
    if not host_ipv4_address:
        module.fail_json(msg="设置主机名IPv4地址需要提供host_ipv4_address参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2/?authkey=%s&action=system.host.ipv4.set" % (
        ip, authkey)

    # 构造IPv4地址数据
    ipv4_data = {
        "host_ipv4_address": host_ipv4_address
    }

    # 转换为JSON格式
    post_data = json.dumps(ipv4_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="设置主机名IPv4地址失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "设置主机名IPv4地址", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_host_ipv6_get(module):
    """获取主机名IPv6地址"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2/?authkey=%s&action=system.host.ipv6.get" % (
        ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取主机名IPv6地址失败: %s" % str(e))

    # 对于获取操作，直接返回响应数据
    if response_data:
        try:
            parsed_data = json.loads(response_data)
            # 检查是否有错误信息
            if 'errmsg' in parsed_data and parsed_data['errmsg']:
                module.fail_json(msg="获取主机名IPv6地址失败", response=parsed_data)
            else:
                module.exit_json(changed=False, host_ipv6=parsed_data)
        except Exception as e:
            module.fail_json(msg="解析响应失败: %s" % str(e))
    else:
        module.fail_json(msg="未收到有效响应")


def system_host_ipv6_set(module):
    """设置主机名IPv6地址"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    host_ipv6_address = module.params['host_ipv6_address']

    # 检查必需参数
    if not host_ipv6_address:
        module.fail_json(msg="设置主机名IPv6地址需要提供host_ipv6_address参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2/?authkey=%s&action=system.host.ipv6.set" % (
        ip, authkey)

    # 构造IPv6地址数据
    ipv6_data = {
        "host_ipv6_address": host_ipv6_address
    }

    # 转换为JSON格式
    post_data = json.dumps(ipv6_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="设置主机名IPv6地址失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "设置主机名IPv6地址", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def main():
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'system_hostname_set', 'system_host_ipv4_get', 'system_host_ipv4_set', 'system_host_ipv6_get', 'system_host_ipv6_set']),
        # 主机名参数
        hostname=dict(type='str', required=False),
        host_ipv4_address=dict(type='str', required=False),
        host_ipv6_address=dict(type='str', required=False)
    )

    # 创建AnsibleModule实例
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # 根据action执行相应操作
    action = module.params['action']

    if action == 'system_hostname_set':
        system_hostname_set(module)
    elif action == 'system_host_ipv4_get':
        system_host_ipv4_get(module)
    elif action == 'system_host_ipv4_set':
        system_host_ipv4_set(module)
    elif action == 'system_host_ipv6_get':
        system_host_ipv6_get(module)
    elif action == 'system_host_ipv6_set':
        system_host_ipv6_set(module)


if __name__ == '__main__':
    main()
