#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys


def system_image_list(module):
    """获取版本镜像列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.image.list" % (ip, authkey)

    try:
        if sys.version_info[0] >= 3:
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取版本镜像列表失败: %s" % str(e))

    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "获取版本镜像列表", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_image_apply(module):
    """指定镜像"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    file_name = module.params['file_name']

    # 构造请求数据
    apply_data = {
        'file_name': file_name
    }

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.image.apply" % (ip, authkey)

    try:
        if sys.version_info[0] >= 3:
            import urllib.request as urllib_request
            post_data = json.dumps(apply_data)
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            import urllib2 as urllib_request
            post_data = json.dumps(apply_data)
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="指定镜像失败: %s" % str(e))

    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "指定镜像", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_image_upload(module):
    """通过 FTP/TFTP 方式上传镜像"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    host = module.params['host']
    location = module.params['location']
    protocol = module.params['protocol']
    port = module.params.get('port')
    username = module.params.get('username')
    password = module.params.get('password')
    use_mgmt_port = module.params.get('use_mgmt_port')
    reboot = module.params.get('reboot')
    save_config = module.params.get('save_config')

    # 构造请求数据
    upload_data = {
        'host': host,
        'location': location,
        'protocol': protocol
    }

    # 添加可选参数
    if port is not None:
        upload_data['port'] = port
    if username is not None:
        upload_data['username'] = username
    if password is not None:
        upload_data['password'] = password
    if use_mgmt_port is not None:
        upload_data['use_mgmt_port'] = use_mgmt_port
    if reboot is not None:
        upload_data['reboot'] = reboot
    if save_config is not None:
        upload_data['save_config'] = save_config

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.image.upload" % (ip, authkey)

    try:
        if sys.version_info[0] >= 3:
            import urllib.request as urllib_request
            post_data = json.dumps(upload_data)
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            import urllib2 as urllib_request
            post_data = json.dumps(upload_data)
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="上传镜像失败: %s" % str(e))

    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "上传镜像", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def main():
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'system_image_list', 'system_image_apply', 'system_image_upload']),
        # system.image.apply 参数
        file_name=dict(type='str', required=False),
        # system.image.upload 参数
        host=dict(type='str', required=False),
        location=dict(type='str', required=False),
        protocol=dict(type='str', required=False),
        port=dict(type='int', required=False),
        username=dict(type='str', required=False),
        password=dict(type='str', required=False, no_log=True),
        use_mgmt_port=dict(type='int', required=False),
        reboot=dict(type='int', required=False),
        save_config=dict(type='int', required=False)
    )

    # 创建AnsibleModule实例
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # 根据action执行相应操作
    action = module.params['action']

    if action == 'system_image_list':
        system_image_list(module)
    elif action == 'system_image_apply':
        system_image_apply(module)
    elif action == 'system_image_upload':
        system_image_upload(module)


if __name__ == '__main__':
    main()
