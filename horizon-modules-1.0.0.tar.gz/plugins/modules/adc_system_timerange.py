#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys

# ADC API响应解析函数


def adc_system_timerange_list(module):
    """获取时间范围列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.timerange.list" % (
        ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取时间范围列表失败: %s" % str(e))

    # 对于获取列表操作，直接返回响应数据，不判断success
    if response_data:
        try:
            parsed_data = json.loads(response_data)
            # 检查是否有错误信息
            if 'errmsg' in parsed_data and parsed_data['errmsg']:
                module.fail_json(msg="获取时间范围列表失败", response=parsed_data)
            else:
                module.exit_json(changed=False, timeranges=parsed_data)
        except Exception as e:
            module.fail_json(msg="解析响应失败: %s" % str(e))
    else:
        module.fail_json(msg="未收到有效响应")


def adc_system_timerange_get(module):
    """获取时间范围详情"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name'] if 'name' in module.params else ""

    # 检查必需参数
    if not name:
        module.fail_json(msg="获取时间范围详情需要提供name参数")

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.timerange.get" % (
        ip, authkey)

    # 构造请求数据
    timerange_data = {
        "name": name
    }

    # 转换为JSON格式
    post_data = json.dumps(timerange_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取时间范围详情失败: %s" % str(e))

    # 对于获取详情操作，直接返回响应数据，不判断success
    if response_data:
        try:
            parsed_data = json.loads(response_data)
            # 检查是否有错误信息
            if 'errmsg' in parsed_data and parsed_data['errmsg']:
                module.fail_json(msg="获取时间范围详情失败", response=parsed_data)
            else:
                module.exit_json(changed=False, timerange=parsed_data)
        except Exception as e:
            module.fail_json(msg="解析响应失败: %s" % str(e))
    else:
        module.fail_json(msg="未收到有效响应")


def adc_system_timerange_add(module):
    """添加时间范围"""
    device_ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name'] if 'name' in module.params else ""

    # 检查必需参数
    if not name:
        module.fail_json(msg="添加时间范围需要提供name参数")

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.timerange.add" % (
        device_ip, authkey)

    # 构造时间范围数据 - 使用API要求的字段名
    timerange_data = {
        "name": name
    }

    # 添加 API 必需和可选参数
    if 'type' in module.params and module.params['type'] is not None:
        timerange_data['type'] = module.params['type']
    if 'day_list' in module.params and module.params['day_list'] is not None:
        timerange_data['day_list'] = module.params['day_list']
    if 'time_list' in module.params and module.params['time_list'] is not None:
        timerange_data['time_list'] = module.params['time_list']

    # 添加可选参数（向后兼容）
    if 'description' in module.params and module.params['description'] is not None:
        timerange_data['description'] = module.params['description']
    if 'start_time' in module.params and module.params['start_time'] is not None:
        timerange_data['start_time'] = module.params['start_time']
    if 'end_time' in module.params and module.params['end_time'] is not None:
        timerange_data['end_time'] = module.params['end_time']
    if 'week_days' in module.params and module.params['week_days'] is not None:
        timerange_data['week_days'] = module.params['week_days']

    # 转换为JSON格式
    post_data = json.dumps(timerange_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="添加时间范围失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "添加时间范围", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def adc_system_timerange_edit(module):
    """编辑时间范围"""
    device_ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name'] if 'name' in module.params else ""

    # 检查必需参数
    if not name:
        module.fail_json(msg="编辑时间范围需要提供name参数")

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.timerange.edit" % (
        device_ip, authkey)

    # 构造时间范围数据 - 使用API要求的字段名
    timerange_data = {
        "name": name
    }

    # 添加 API 必需和可选参数
    if 'type' in module.params and module.params['type'] is not None:
        timerange_data['type'] = module.params['type']
    if 'day_list' in module.params and module.params['day_list'] is not None:
        timerange_data['day_list'] = module.params['day_list']
    if 'time_list' in module.params and module.params['time_list'] is not None:
        timerange_data['time_list'] = module.params['time_list']

    # 添加可选参数（向后兼容）
    if 'description' in module.params and module.params['description'] is not None:
        timerange_data['description'] = module.params['description']
    if 'start_time' in module.params and module.params['start_time'] is not None:
        timerange_data['start_time'] = module.params['start_time']
    if 'end_time' in module.params and module.params['end_time'] is not None:
        timerange_data['end_time'] = module.params['end_time']
    if 'week_days' in module.params and module.params['week_days'] is not None:
        timerange_data['week_days'] = module.params['week_days']

    # 转换为JSON格式
    post_data = json.dumps(timerange_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="编辑时间范围失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "编辑时间范围", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def adc_system_timerange_del(module):
    """删除时间范围"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name'] if 'name' in module.params else ""

    # 检查必需参数
    if not name:
        module.fail_json(msg="删除时间范围需要提供name参数")

    # 构造请求URL (使用兼容Python 2.7的字符串格式化)
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.timerange.del" % (
        ip, authkey)

    # 构造请求数据
    timerange_data = {
        "name": name
    }

    # 转换为JSON格式
    post_data = json.dumps(timerange_data)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="删除时间范围失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "删除时间范围", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def main():
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'system_timerange_list', 'system_timerange_get', 'system_timerange_add', 'system_timerange_edit', 'system_timerange_del']),
        # 时间范围参数
        name=dict(type='str', required=False),
        description=dict(type='str', required=False),
        start_time=dict(type='str', required=False),
        end_time=dict(type='str', required=False),
        week_days=dict(type='list', required=False),
        # API 参数
        type=dict(type='int', required=False),
        day_list=dict(type='list', required=False),
        time_list=dict(type='list', required=False)
    )

    # 创建AnsibleModule实例
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # 根据action执行相应操作
    action = module.params['action']

    if action == 'system_timerange_list':
        adc_system_timerange_list(module)
    elif action == 'system_timerange_get':
        adc_system_timerange_get(module)
    elif action == 'system_timerange_add':
        adc_system_timerange_add(module)
    elif action == 'system_timerange_edit':
        adc_system_timerange_edit(module)
    elif action == 'system_timerange_del':
        adc_system_timerange_del(module)


if __name__ == '__main__':
    main()
