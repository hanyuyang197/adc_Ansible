#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible,
    send_request
)
import json
import sys
import os

# def send_request(url, post_data=None):
#     """发送HTTP请求的通用函数"""
#     response_data = ""
#     try:
#         if sys.version_info[0] >= 3:
#             import urllib.request as urllib_request
#             if post_data:
#                 post_data = post_data.encode('utf-8')
#                 req = urllib_request.Request(url, data=post_data, method='POST', headers={
#                                              'Content-Type': 'application/json'})
#             else:
#                 req = urllib_request.Request(url, method='GET')
#             response = urllib_request.urlopen(req)
#             response_data = response.read().decode('utf-8')
#         else:
#             import urllib2 as urllib_request
#             if post_data:
#                 post_data = post_data.encode('utf-8')
#                 req = urllib_request.Request(url, data=post_data, headers={
#                                              'Content-Type': 'application/json'})
#                 req.get_method = lambda: 'POST'
#             else:
#                 req = urllib_request.Request(url)
#                 req.get_method = lambda: 'GET'
#             response = urllib_request.urlopen(req)
#             response_data = response.read()
#     except Exception as e:
#         raise Exception(str(e))

#     # 直接返回响应内容，不尝试解析JSON
#     return response_data


def slb_erule_upload(module):
    """erule上传"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']
    file_path = module.params.get('file_path')

    # 检查必要参数
    if not name:
        module.fail_json(msg="erule上传需要提供name参数")
    if not file_path or not os.path.exists(file_path):
        module.fail_json(msg="erule上传需要提供有效的file_path参数")

    # 读取文件内容
    try:
        with open(file_path, 'rb') as f:
            file_content = f.read()
    except Exception as e:
        module.fail_json(msg="读取文件失败: %s" % str(e))

    # 构造请求URL - 包含name参数
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erule.upload&name=%s" % (
        ip, authkey, name)

    try:
        # 根据Python版本处理文件上传
        if sys.version_info[0] >= 3:
            # Python 3 - 使用urllib处理multipart/form-data上传
            import urllib.request as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append(
                'Content-Type: application/octet-stream')  # 二进制文件类型
            body_parts.append('')
            # 将body_parts转换为bytes并加上文件内容
            body_content = b''
            for part in body_parts:
                body_content += part.encode('utf-8') + b'\r\n'
            body_content += file_content
            body_content += b'\r\n--%s--\r\n' % boundary.encode('utf-8')

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2 - 使用urllib2处理multipart/form-data上传
            import urllib2 as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append(
                'Content-Type: application/octet-stream')  # 二进制文件类型
            body_parts.append('')
            # 将body_parts转换为字符串并加上文件内容
            body_content = ''
            for part in body_parts:
                body_content += part + '\r\n'
            body_content += file_content
            body_content += '\r\n--%s--\r\n' % boundary

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 使用通用响应解析函数
        if response_data:
            success, result_dict = format_adc_response_for_ansible(
                response_data, "erule上传", True)
            if success:
                module.exit_json(**result_dict)
            else:
                module.fail_json(**result_dict)
        else:
            module.fail_json(msg="未收到有效响应")
    except Exception as e:
        module.fail_json(msg="erule上传失败: %s" % str(e))


def slb_erule_content_add(module):
    """erule在线编辑"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']
    content = module.params['content']

    if not name or not content:
        module.fail_json(msg="erule在线编辑需要提供name和content参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erule.content.add" % (
        ip, authkey)

    erule_data = {
        "name": name,
        "content": content
    }

    post_data = json.dumps(erule_data)

    try:
        response_data = send_request(url, post_data)
        success, result_dict = format_adc_response_for_ansible(
            response_data, "erule在线编辑", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    except Exception as e:
        module.fail_json(msg="erule在线编辑失败: %s" % str(e))


def slb_erule_del(module):
    """erule文件删除"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    if not name:
        module.fail_json(msg="erule文件删除需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erule.del" % (
        ip, authkey)

    erule_data = {
        "name": name
    }

    post_data = json.dumps(erule_data)

    try:
        response_data = send_request(url, post_data)
        success, result_dict = format_adc_response_for_ansible(
            response_data, "erule文件删除", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    except Exception as e:
        module.fail_json(msg="erule文件删除失败: %s" % str(e))


def slb_erule_list(module):
    """erule文件列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erule.list" % (
        ip, authkey)

    try:
        response_data = send_request(url)
        # 直接返回响应数据，不解析为特定格式
        module.exit_json(changed=False, erule_list=response_data)
    except Exception as e:
        module.fail_json(msg="erule文件列表获取失败: %s" % str(e))


def slb_erulefiles_upload(module):
    """erule服务器文件上传"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']
    file_path = module.params.get('file_path')

    # 检查必要参数
    if not name:
        module.fail_json(msg="erule服务器文件上传需要提供name参数")
    if not file_path or not os.path.exists(file_path):
        module.fail_json(msg="erule服务器文件上传需要提供有效的file_path参数")

    # 读取文件内容
    try:
        with open(file_path, 'rb') as f:
            file_content = f.read()
    except Exception as e:
        module.fail_json(msg="读取文件失败: %s" % str(e))

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erulefiles.upload" % (
        ip, authkey)

    try:
        # 根据Python版本处理文件上传
        if sys.version_info[0] >= 3:
            # Python 3 - 使用urllib处理multipart/form-data上传
            import urllib.request as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append(
                'Content-Type: application/octet-stream')  # 二进制文件类型
            body_parts.append('')
            body_parts.append('--%s' % boundary)
            body_parts.append('Content-Disposition: form-data; name="name"')
            body_parts.append('')
            body_parts.append(name)
            body_parts.append('')
            # 将body_parts转换为bytes并加上文件内容
            body_content = b''
            for part in body_parts:
                body_content += part.encode('utf-8') + b'\r\n'
            body_content += file_content
            body_content += b'\r\n--%s--\r\n' % boundary.encode('utf-8')

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2 - 使用urllib2处理multipart/form-data上传
            import urllib2 as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append(
                'Content-Type: application/octet-stream')  # 二进制文件类型
            body_parts.append('')
            body_parts.append('--%s' % boundary)
            body_parts.append('Content-Disposition: form-data; name="name"')
            body_parts.append('')
            body_parts.append(name)
            body_parts.append('')
            # 将body_parts转换为字符串并加上文件内容
            body_content = ''
            for part in body_parts:
                body_content += part + '\r\n'
            body_content += file_content
            body_content += '\r\n--%s--\r\n' % boundary

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 使用通用响应解析函数
        if response_data:
            success, result_dict = format_adc_response_for_ansible(
                response_data, "erule服务器文件上传", True)
            if success:
                module.exit_json(**result_dict)
            else:
                module.fail_json(**result_dict)
        else:
            module.fail_json(msg="未收到有效响应")
    except Exception as e:
        module.fail_json(msg="erule服务器文件上传失败: %s" % str(e))


def slb_erulefiles_del(module):
    """erule服务器文件删除"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    if not name:
        module.fail_json(msg="erule服务器文件删除需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erulefiles.del" % (
        ip, authkey)

    erule_data = {
        "name": name
    }

    post_data = json.dumps(erule_data)

    try:
        response_data = send_request(url, post_data)
        success, result_dict = format_adc_response_for_ansible(
            response_data, "erule服务器文件删除", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    except Exception as e:
        module.fail_json(msg="erule服务器文件删除失败: %s" % str(e))


def slb_erulefiles_list(module):
    """erule服务器文件列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erulefiles.list" % (
        ip, authkey)

    try:
        response_data = send_request(url)
        # 直接返回响应数据，不解析为特定格式
        module.exit_json(changed=False, erulefiles_list=response_data)
    except Exception as e:
        module.fail_json(msg="erule服务器文件列表获取失败: %s" % str(e))


def slb_erule_list_withcommon(module):
    """erule文件获取 common 和本分区"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.erule.list.withcommon" % (
        ip, authkey)

    try:
        response_data = send_request(url)
        # 直接返回响应数据，不解析为特定格式
        module.exit_json(changed=False, erule_list_withcommon=response_data)
    except Exception as e:
        module.fail_json(msg="erule文件获取 common 和本分区失败: %s" % str(e))


def main():
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'slb_erule_upload', 'slb_erule_content_add', 'slb_erule_del',
            'slb_erule_list', 'slb_erulefiles_upload', 'slb_erulefiles_del',
            'slb_erulefiles_list', 'slb_erule_list_withcommon'
        ]),
        # erule参数
        name=dict(type='str', required=False),
        content=dict(type='str', required=False),
        file_path=dict(type='str', required=False)  # 上传时的本地文件路径
    )

    # 创建AnsibleModule实例
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False,
        required_if=[
            ['action', 'slb_erule_upload', ['file_path']],
            ['action', 'slb_erulefiles_upload', ['file_path']]
        ]
    )

    # 根据action执行相应操作
    action = module.params['action']

    if action == 'slb_erule_upload':
        slb_erule_upload(module)
    elif action == 'slb_erule_content_add':
        slb_erule_content_add(module)
    elif action == 'slb_erule_del':
        slb_erule_del(module)
    elif action == 'slb_erule_list':
        slb_erule_list(module)
    elif action == 'slb_erulefiles_upload':
        slb_erulefiles_upload(module)
    elif action == 'slb_erulefiles_del':
        slb_erulefiles_del(module)
    elif action == 'slb_erulefiles_list':
        slb_erulefiles_list(module)
    elif action == 'slb_erule_list_withcommon':
        slb_erule_list_withcommon(module)


if __name__ == '__main__':
    main()
