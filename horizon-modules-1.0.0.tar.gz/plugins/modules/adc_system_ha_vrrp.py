#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2024, Horizon Inc.
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys

# ADC API响应解析函数


def send_request(url, data=None, method='GET'):
    """发送HTTP请求到ADC设备"""
    import sys
    response_data = None

    if method == 'POST' and data:
        data_json = json.dumps(data)
        data_bytes = data_json.encode('utf-8')

        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, data=data_bytes)
            req.add_header('Content-Type', 'application/json')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url, data=data_bytes)
            req.add_header('Content-Type', 'application/json')
    else:
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url)
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)

    response = urllib_request.urlopen(req)
    response_data = response.read()

    # 正确处理响应数据的编码
    # if isinstance(response_data, bytes):
    #     # 尝试UTF-8解码，如果失败则使用latin1作为后备
    #     try:
    #         response_text = response_data.decode('utf-8')
    #     except UnicodeDecodeError:
    #         response_text = response_data.decode('latin1')
    # else:
    #     response_text = response_data

    # 安全地解析JSON响应

    return format_adc_response_for_ansible(
            response_data, "vrrp", True)



DOCUMENTATION = r'''
---
module: adc_vrrp
short_description: Manage ADC system HA VRRP configuration
description:
  - Manage High Availability VRRP configuration for ADC devices.
  - Supports global configuration, groups, heartbeat interfaces, floating IPs, and more.
version_added: "1.0.0"
options:
  vrrp_component:
    description:
      - The VRRP component to manage.
    type: str
    required: true
    choices: [ global, group, heartbeat_eth, heartbeat_trunk, floating_ip, force_offline, gateway_track, route_track, pool_track, ethernet_track, trunk_track, vlan_track ]
  action:
    description:
      - The action to perform on the VRRP component.
    type: str
    required: true
    choices: [ get, set, add, list, edit, delete ]
  # Global configuration parameters
  enabled:
    description:
      - Enable VRRP (0=disabled, 1=enabled).
    type: int
    choices: [0, 1]
  as_model:
    description:
      - Enable AS mode (0=disabled, 1=enabled).
    type: int
    choices: [0, 1]
  unit_id:
    description:
      - Unit ID (0-8).
    type: int
  interval:
    description:
      - Heartbeat interval (1-255).
    type: int
  retry:
    description:
      - Retry count (2-200).
    type: int
  delay:
    description:
      - Delay (1-100).
    type: int
  cluster_id:
    description:
      - Cluster ID (0-7).
    type: int
  # Group parameters
  group_id:
    description:
      - Group ID (0-8).
    type: int
  priority:
    description:
      - Priority (1-200).
    type: int
  preempt_th:
    description:
      - Preempt threshold (0-100).
    type: int
  preempt_dis:
    description:
      - Disable preempt (0=enabled, 1=disabled).
    type: int
    choices: [0, 1]
  priority_threshold:
    description:
      - Priority threshold (1-200).
    type: int
  failback_first_device:
    description:
      - Failback to first device (0=disabled, 1=enabled).
    type: int
    choices: [0, 1]
  order_list:
    description:
      - Order list (space-separated integers).
    type: str
  # Heartbeat interface parameters
  slot:
    description:
      - Ethernet interface slot (0-8).
    type: int
  port:
    description:
      - Ethernet interface port (0-7).
    type: int
  vlan_id:
    description:
      - VLAN ID (0-4094).
    type: int
  trunk_id:
    description:
      - Trunk ID (1-8).
    type: int
  # Floating IP parameters
  floating_ip:
    description:
      - Floating IP address (IPv4/IPv6).
    type: str
  # Force offline parameters
  force_offline:
    description:
      - Force offline (0=disabled, 1=enabled).
    type: int
    choices: [0, 1]
  all_partitions:
    description:
      - Apply to all partitions (0=disabled, 1=enabled).
    type: int
    choices: [0, 1]
  # Track parameters
  ip:
    description:
      - IP address for tracking (IPv4/IPv6).
    type: str
  netmask:
    description:
      - Netmask or prefix for route tracking.
    type: str
  pool_name:
    description:
      - Pool name for pool tracking.
    type: str
  min_up_members:
    description:
      - Minimum up members for pool tracking.
    type: int
  member_priority:
    description:
      - Member priority for trunk tracking.
    type: int
  timeout:
    description:
      - Timeout for VLAN tracking.
    type: int
author:
  - Horizon Inc.
'''

EXAMPLES = r'''
- name: Get VRRP global configuration
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_global_get

- name: Enable VRRP
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_global_set
    enabled: 1
    unit_id: 1
    interval: 10
    retry: 3

- name: Add VRRP group
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_group_add
    group_id: 1
    priority: 150

- name: List VRRP groups
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_group_list

- name: Add Ethernet heartbeat interface
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_heart_eth_add
    slot: 0
    port: 1
    vlan_id: 100

- name: Add floating IP
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_floating_ip_add
    group_id: 1
    floating_ip: "192.168.1.100"

- name: Set force offline
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_force_offline_set
    force_offline: 1

- name: Add gateway tracking
  adc_vrrp:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: vrrp_track_gateway_add
    group_id: 1
    priority: 50
    track_ip: "10.0.0.1"
'''

RETURN = r'''
global_config:
  description: VRRP global configuration when vrrp_component=global and action=get
  returned: when vrrp_component=global and action=get
  type: dict
  sample: {
    "enabled": 1,
    "as_mode": 0,
    "unit_id": 1,
    "interval": 10,
    "retry": 3
  }
groups:
  description: List of VRRP groups when vrrp_component=group and action=list
  returned: when vrrp_component=group and action=list
  type: list
  sample: [
    {
      "group_id": 1,
      "priority": 150,
      "preempt_th": 0
    }
  ]
msg:
  description: Result message
  returned: always
  type: str
  sample: "VRRP group added successfully"
'''


def vrrp_global_get(module):
    """Get VRRP global configuration"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.global.get" % (
        ip, authkey)

    # Make API call
    return send_request(url, method='GET')




def vrrp_global_set(module):
    """Set VRRP global configuration"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.global.set" % (
        ip, authkey)

    # Prepare parameters（与API文档保持一致）
    params = {}

    # Add optional parameters if provided（注意：as_model要映射为as_mode）
    if module.params['enabled'] is not None:
        params['enabled'] = module.params['enabled']
    if module.params['as_model'] is not None:
        params['as_model'] = module.params['as_model']
    if module.params['unit_id'] is not None:
        params['unit_id'] = module.params['unit_id']
    if module.params['interval'] is not None:
        params['interval'] = module.params['interval']
    if module.params['retry'] is not None:
        params['retry'] = module.params['retry']
    if module.params['delay'] is not None:
        params['delay'] = module.params['delay']
    if module.params['cluster_id'] is not None:
        params['cluster_id'] = module.params['cluster_id']

    # Make API call
    return send_request(url, params, method='POST')



def vrrp_group_add(module):
    """Add VRRP group"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.group.add" % (
        ip, authkey)

    # Prepare parameters
    params = {}

    # Required parameters
    if module.params['group_id'] is not None:
        params['group_id'] = module.params['group_id']
    else:
        module.fail_json(msg="group_id is required for add group action")

    # Optional parameters
    if module.params['priority'] is not None:
        params['priority'] = module.params['priority']
    if module.params['preempt_th'] is not None:
        params['preempt_th'] = module.params['preempt_th']
    if module.params['preempt_dis'] is not None:
        params['preempt_dis'] = module.params['preempt_dis']
    if module.params['priority_threshold'] is not None:
        params['priority_threshold'] = module.params['priority_threshold']
    if module.params['failback_first_device'] is not None:
        params['failback_first_device'] = module.params['failback_first_device']
    if module.params['order_list'] is not None:
        params['order_list'] = module.params['order_list']
    if module.params['manually_standby'] is not None:
        # 已作废参数，保留兼容性（API文档第4576行说明已作废）
        params['manually_standby'] = module.params['manually_standby']

    # Make API call
    return send_request(url, params, method='POST')



def vrrp_group_list(module):
    """List VRRP groups"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.group.list" % (
        ip, authkey)

    # Make API call
    return send_request(url, method='GET')




def vrrp_heart_eth_add(module):
    """Add Ethernet heartbeat interface"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.heart_eth.add" % (
        ip, authkey)

    # Prepare parameters
    params = {}

    # Required parameters
    if module.params['slot'] is not None:
        params['slot'] = module.params['slot']
    else:
        module.fail_json(msg="slot is required for add heartbeat_eth action")

    if module.params['port'] is not None:
        params['port'] = module.params['port']
    else:
        module.fail_json(msg="port is required for add heartbeat_eth action")

    if module.params['vlan_id'] is not None:
        params['vlan_id'] = module.params['vlan_id']
    else:
        module.fail_json(
            msg="vlan_id is required for add heartbeat_eth action")

    # Make API call
    return send_request(url, params, method='POST')



def vrrp_floating_ip_add(module):
    """Add floating IP"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.floating_ip.add" % (
        ip, authkey)

    # Prepare parameters
    params = {}

    # Required parameters
    if module.params['group_id'] is not None:
        params['group_id'] = module.params['group_id']
    else:
        module.fail_json(msg="group_id is required for add floating_ip action")

    if module.params['floating_ip'] is not None:
        params['floating_ip'] = module.params['floating_ip']
    else:
        module.fail_json(
            msg="floating_ip is required for add floating_ip action")

    # Make API call
    return send_request(url, params, method='POST')


def vrrp_force_offline_set(module):
    """Set force offline"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.force_offline.set" % (
        ip, authkey)

    # Prepare parameters
    params = {}

    # Optional parameters
    if module.params['group_id'] is not None:
        params['group_id'] = module.params['group_id']
    if module.params['force_offline'] is not None:
        params['force_offline'] = module.params['force_offline']
    if module.params['all_partitions'] is not None:
        params['all_partitions'] = module.params['all_partitions']

    # Make API call
    return send_request(url, params, method='POST')



def vrrp_track_gateway_add(module):
    """Add gateway tracking"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL（与API文档保持一致）
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=vrrp.track.gateway.add" % (
        ip, authkey)

    # Prepare parameters
    params = {}

    # Required parameters
    if module.params['group_id'] is not None:
        params['group_id'] = module.params['group_id']
    else:
        module.fail_json(
            msg="group_id is required for add gateway_track action")

    if module.params['priority'] is not None:
        params['priority'] = module.params['priority']
    else:
        module.fail_json(
            msg="priority is required for add gateway_track action")

    if module.params['track_ip'] is not None:
        params['ip'] = module.params['track_ip']
    else:
        module.fail_json(
            msg="track_ip is required for add gateway_track action")

    # Make API call
    return send_request(url, params, method='POST')


def main():
    # Define module arguments
    argument_spec = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
                    'vrrp_global_get', 'vrrp_global_set',
                    'vrrp_group_add', 'vrrp_group_list',
                    'vrrp_heart_eth_add', 'vrrp_floating_ip_add',
                    'vrrp_force_offline_set', 'vrrp_track_gateway_add']),
        # Global configuration parameters
        enabled=dict(type='int', choices=[0, 1]),
        as_model=dict(type='int', choices=[0, 1]),
        unit_id=dict(type='int'),
        interval=dict(type='int'),
        retry=dict(type='int'),
        delay=dict(type='int'),
        cluster_id=dict(type='int'),
        # Group parameters
        group_id=dict(type='int'),
        priority=dict(type='int'),
        preempt_th=dict(type='int'),
        preempt_dis=dict(type='int', choices=[0, 1]),
        priority_threshold=dict(type='int'),
        failback_first_device=dict(type='int', choices=[0, 1]),
        order_list=dict(type='str'),
        manually_standby=dict(type='int', choices=[0, 1]),  # 已作废参数，保留兼容性
        # Heartbeat interface parameters
        slot=dict(type='int'),
        port=dict(type='int'),
        vlan_id=dict(type='int'),
        trunk_id=dict(type='int'),
        # Floating IP parameters
        floating_ip=dict(type='str'),
        # Force offline parameters
        force_offline=dict(type='int', choices=[0, 1]),
        all_partitions=dict(type='int', choices=[0, 1]),
        # Track parameters
        track_ip=dict(type='str'),
        netmask=dict(type='str'),
        pool_name=dict(type='str'),
        min_up_members=dict(type='int'),
        member_priority=dict(type='int'),
        timeout=dict(type='int'),
    )

    # Create Ansible module
    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    # Extract module parameters
    action = str(module.params['action'])

    # If in check mode, exit without making changes
    if module.check_mode:
        module.exit_json(changed=False)

    # Perform requested action based on VRRP component
    if action == 'vrrp_global_get':
        success, result_dict = vrrp_global_get(module)
    elif action == 'vrrp_global_set':
        success, result_dict = vrrp_global_set(module)
    elif action == 'vrrp_group_add':
        success, result_dict = vrrp_group_add(module)
    elif action == 'vrrp_group_list':
        success, result_dict = vrrp_group_list(module)
    elif action == 'vrrp_heart_eth_add':
        success, result_dict = vrrp_heart_eth_add(module)
    elif action == 'vrrp_floating_ip_add':
        success, result_dict = vrrp_floating_ip_add(module)
    elif action == 'vrrp_force_offline_set':
        success, result_dict = vrrp_force_offline_set(module)
    elif action == 'vrrp_track_gateway_add':
        success, result_dict = vrrp_track_gateway_add(module)

    if success:
        module.exit_json(**result_dict)
    else:
        module.fail_json(**result_dict)




if __name__ == '__main__':
    main()
