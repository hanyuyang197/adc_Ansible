#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
# Python 2/3兼容性处理
try:
    # Python 2
    import urllib2 as urllib_request
except ImportError:
    # Python 3
    import urllib.request as urllib_request
    import urllib.error as urllib_error

DOCUMENTATION = '''
---
module: adc_slb_sslclient
short_description: Manage ADC SLB Client SSL profiles
description:
    - Manage ADC SLB Client SSL profiles including add, edit, delete, list and get operations
version_added: "2.4"
options:
    ip:
        description:
            - The IP address of the ADC device
        required: true
    authkey:
        description:
            - The authentication key for the ADC device
        required: true
    action:
        description:
            - The action to perform (list_profiles, list_profiles_withcommon, get_profile, add_profile, edit_profile, delete_profile)
        required: true
        choices: ['list_profiles', 'list_profiles_withcommon', 'get_profile', 'add_profile', 'edit_profile', 'delete_profile']
    name:
        description:
            - The name of the client SSL profile
        required: false
    cert:
        description:
            - First certificate name (optional RSA,ECC,GM signature certificate)
        required: false
    chain_cert:
        description:
            - First certificate chain name (optional RSA,ECC,GM signature certificate)
        required: false
    key:
        description:
            - First certificate private key name
        required: false
    password:
        description:
            - First certificate password
        required: false
    dcert:
        description:
            - Second certificate name
        required: false
    dchain_cert:
        description:
            - Second certificate chain name
        required: false
    dkey:
        description:
            - Second certificate private key name
        required: false
    dpassword:
        description:
            - Second certificate password
        required: false
    ecert:
        description:
            - GM encryption certificate name
        required: false
    ekey:
        description:
            - GM encryption certificate private key
        required: false
    epassword:
        description:
            - GM encryption certificate password
        required: false
    resume_mode:
        description:
            - Session cache mode, 0 for session ticket, 1 for session id
        required: false
    cache_num:
        description:
            - Session cache size (0-131072)
        required: false
    cache_timeout:
        description:
            - Session cache timeout in seconds (0-10000000)
        required: false
    disable_renegotiate:
        description:
            - Disable renegotiation, 0 to disable, 1 to enable
        required: false
    disable_ssl30:
        description:
            - SSL3.0 protocol version switch, 0 to enable, 1 to disable
        required: false
    disable_tls10:
        description:
            - TLS1.0 protocol version switch, 0 to enable, 1 to disable
        required: false
    disable_tls11:
        description:
            - TLS1.1 protocol version switch, 0 to enable, 1 to disable
        required: false
    disable_tls12:
        description:
            - TLS1.2 protocol version switch, 0 to enable, 1 to disable
        required: false
author:
    - Your Name
'''

EXAMPLES = '''
# List all client SSL profiles
- adc_slb_sslclient:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: "list_profiles"

# Get a specific client SSL profile
- adc_slb_sslclient:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: "get_profile"
    name: "my_ssl_profile"

# Add a client SSL profile
- adc_slb_sslclient:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: "add_profile"
    name: "my_ssl_profile"
    cert: "my_cert"

# Edit a client SSL profile
- adc_slb_sslclient:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: "edit_profile"
    name: "my_ssl_profile"
    cert: "new_cert"

# Delete a client SSL profile
- adc_slb_sslclient:
    ip: "192.168.1.1"
    authkey: "your_auth_key"
    action: "delete_profile"
    name: "my_ssl_profile"
'''

RETURN = '''
result:
    description: The response from the ADC device
    returned: success
    type: dict
'''


def send_request(url, data=None, method='GET'):
    """Send HTTP request to ADC device"""
    response_data = None
    try:
        if method == 'POST' and data:
            data_json = json.dumps(data)
            data_bytes = data_json.encode('utf-8')
            req = urllib_request.Request(url, data=data_bytes)
            req.add_header('Content-Type', 'application/json')
        else:
            req = urllib_request.Request(url)

        response = urllib_request.urlopen(req)
        response_data = response.read()

        # 正确处理响应数据的编码
        if isinstance(response_data, bytes):
            # 尝试UTF-8解码，如果失败则使用latin1作为后备
            try:
                response_text = response_data.decode('utf-8')
            except UnicodeDecodeError:
                response_text = response_data.decode('latin1')
        else:
            response_text = response_data

        result = json.loads(response_text)

        # 标准化响应格式
        # 成功响应保持原样
        # 错误响应标准化为 {"result":"error","errcode":"REQUEST_ERROR","errmsg":"..."}
        if isinstance(result, dict) and 'status' in result and result['status'] is False:
            # 修复Unicode解码错误：确保错误消息正确处理中文字符
            error_msg = result.get('msg', '')
            if isinstance(error_msg, bytes):
                try:
                    error_msg = error_msg.decode('utf-8')
                except UnicodeDecodeError:
                    error_msg = error_msg.decode('latin1')

            return {
                'result': 'error',
                'errcode': 'REQUEST_ERROR',
                'errmsg': error_msg if error_msg else '请求失败'
            }
        else:
            return result
    except UnicodeDecodeError as e:
        # 如果JSON解析失败，直接返回原始响应数据
        return {
            'result': 'success',
            'data': str(response_data) if response_data is not None else '',
            'raw_response': True
        }
    except Exception as e:
        return {
            'result': 'error',
            'errcode': 'REQUEST_EXCEPTION',
            'errmsg': str(e)
        }


def slb_sslclient_list(module):
    """List all client SSL profiles"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.list" % (
        ip, authkey)
    result = send_request(url)
    return result


def slb_sslclient_list_withcommon(module):
    """List all client SSL profiles including common partition"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.list.withcommon" % (
        ip, authkey)
    result = send_request(url)
    return result


def slb_sslclient_get(module):
    """Get a specific client SSL profile"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    if not name:
        module.fail_json(msg="获取客户端SSL卸载模板需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.get" % (
        ip, authkey)

    data = {
        "name": name
    }

    result = send_request(url, data, method='POST')
    return result


def slb_sslclient_add(module):
    """Add a new client SSL profile"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    # Check required parameters
    if not name:
        module.fail_json(msg="添加客户端SSL卸载模板需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.add" % (
        ip, authkey)

    # Construct profile data
    profile_data = {
        "name": name
    }

    # Only include parameters that are explicitly defined in YAML
    optional_params = [
        'cert', 'chain_cert', 'key', 'password', 'dcert', 'dchain_cert',
        'dkey', 'dpassword', 'ecert', 'ekey', 'epassword', 'resume_mode',
        'cache_num', 'cache_timeout', 'disable_renegotiate', 'disable_ssl30',
        'disable_tls10', 'disable_tls11', 'disable_tls12'
    ]

    for param in optional_params:
        if module.params[param] is not None:
            profile_data[param] = module.params[param]

    # Send POST request
    result = send_request(url, profile_data, method='POST')
    return result


def slb_sslclient_edit(module):
    """Edit an existing client SSL profile"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    # Check required parameters
    if not name:
        module.fail_json(msg="编辑客户端SSL卸载模板需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.edit" % (
        ip, authkey)

    # Construct profile data
    profile_data = {
        "name": name
    }

    # Only include parameters that are explicitly defined in YAML
    optional_params = [
        'cert', 'chain_cert', 'key', 'password', 'dcert', 'dchain_cert',
        'dkey', 'dpassword', 'ecert', 'ekey', 'epassword', 'resume_mode',
        'cache_num', 'cache_timeout', 'disable_renegotiate', 'disable_ssl30',
        'disable_tls10', 'disable_tls11', 'disable_tls12'
    ]

    for param in optional_params:
        if module.params[param] is not None:
            profile_data[param] = module.params[param]

    # Send POST request
    result = send_request(url, profile_data, method='POST')
    return result


def slb_sslclient_del(module):
    """Delete a client SSL profile"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']

    # Check required parameters
    if not name:
        module.fail_json(msg="删除客户端SSL卸载模板需要提供name参数")

    url = "http://%s/adcapi/v2.0/?authkey=%s&action=slb.sslclient.del" % (
        ip, authkey)

    # Construct profile data
    profile_data = {
        "name": name
    }

    # Send POST request
    result = send_request(url, profile_data, method='POST')
    return result


def main():
    module = AnsibleModule(
        argument_spec=dict(
            ip=dict(type='str', required=True),
            authkey=dict(type='str', required=True, no_log=True),
            action=dict(type='str', required=True, choices=[
                'slb_sslclient_list', 'slb_sslclient_list_withcommon', 'slb_sslclient_get',
                'slb_sslclient_add', 'slb_sslclient_edit', 'slb_sslclient_del'
            ]),
            name=dict(type='str', required=False),
            cert=dict(type='str', required=False),
            chain_cert=dict(type='str', required=False),
            key=dict(type='str', required=False, no_log=True),
            password=dict(type='str', required=False, no_log=True),
            dcert=dict(type='str', required=False),
            dchain_cert=dict(type='str', required=False),
            dkey=dict(type='str', required=False, no_log=True),
            dpassword=dict(type='str', required=False, no_log=True),
            ecert=dict(type='str', required=False),
            ekey=dict(type='str', required=False, no_log=True),
            epassword=dict(type='str', required=False, no_log=True),
            resume_mode=dict(type='int', required=False),
            cache_num=dict(type='int', required=False),
            cache_timeout=dict(type='int', required=False),
            disable_renegotiate=dict(type='int', required=False),
            disable_ssl30=dict(type='int', required=False),
            disable_tls10=dict(type='int', required=False),
            disable_tls11=dict(type='int', required=False),
            disable_tls12=dict(type='int', required=False),
        ),
        supports_check_mode=False
    )

    action = module.params['action']

    if action == 'slb_sslclient_list':
        result = slb_sslclient_list(module)
    elif action == 'slb_sslclient_list_withcommon':
        result = slb_sslclient_list_withcommon(module)
    elif action == 'slb_sslclient_get':
        result = slb_sslclient_get(module)
    elif action == 'slb_sslclient_add':
        result = slb_sslclient_add(module)
    elif action == 'slb_sslclient_edit':
        result = slb_sslclient_edit(module)
    elif action == 'slb_sslclient_del':
        result = slb_sslclient_del(module)


    # 统一使用标准的ADC响应格式处理结果
    # 成功响应: {"result":"success"} 或直接返回数据
    # 错误响应: {"result":"error","errcode":"...","errmsg":"..."}
    if isinstance(result, dict):
        if result.get('result', '').lower() == 'success':
            # 成功响应
            module.exit_json(changed=True, result=result)
        elif 'errcode' in result and result['errcode']:
            # 错误响应 - 修复Unicode解码错误
            try:
                error_msg = result.get('errmsg', '未知错误')
                # 确保错误消息正确处理Unicode字符
                if isinstance(error_msg, bytes):
                    try:
                        error_msg = error_msg.decode('utf-8')
                    except UnicodeDecodeError:
                        error_msg = error_msg.decode('latin1')
                formatted_msg = "操作失败: %s" % error_msg
            except Exception:
                formatted_msg = "操作失败: 未知错误"

            module.fail_json(msg=formatted_msg, result=result)
        else:
            # 查询类API直接返回数据
            module.exit_json(changed=False, result=result)
    elif isinstance(result, list):
        # 列表类型直接返回
        module.exit_json(changed=False, result=result)
    else:
        # 其他类型也直接返回
        module.exit_json(changed=False, result=result)


if __name__ == '__main__':
    main()
