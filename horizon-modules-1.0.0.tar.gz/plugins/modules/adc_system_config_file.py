#!/usr/bin/python
# -*- coding: utf-8 -*-

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.horizon.modules.plugins.module_utils.adc_common import (
    make_adc_request,
    format_adc_response,
    check_adc_auth,
    handle_adc_error,
    build_adc_params,
    validate_adc_params,
    adc_result_check,
    adc_format_output,
    build_params_with_optional,
    make_http_request,
    get_param_if_exists,
    create_adc_module_args,
    adc_response_to_ansible_result,
    format_adc_response_for_ansible
)
import json
import sys
import os


def system_config_add(module):
    """添加配置文件"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    file_name = module.params['file_name']
    description = module.params['description']
    flag = module.params['flag']
    encrypt = module.params['encrypt']
    overwrite = module.params['overwrite']
    password = module.params['password']

    # 检查必需参数
    if not file_name:
        module.fail_json(msg="添加配置文件需要提供file_name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.add" % (
        ip, authkey)

    # 构造配置文件数据
    config_data = {
        "file_name": file_name
    }

    # 添加可选参数
    if description is not None:
        config_data["description"] = description
    if flag is not None:
        config_data["flag"] = flag
    if encrypt is not None:
        config_data["encrypt"] = encrypt
    if overwrite is not None:
        config_data["overwrite"] = overwrite
    if password is not None:
        config_data["password"] = password

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = json.dumps(config_data)
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            post_data = json.dumps(config_data)
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="添加配置文件失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "添加配置文件", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_config_list(module):
    """获取配置文件列表"""
    ip = module.params['ip']
    authkey = module.params['authkey']

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.list" % (
        ip, authkey)

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理请求
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            req = urllib_request.Request(url, method='GET')
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            req = urllib_request.Request(url)
            req.get_method = lambda: 'GET'
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="获取配置文件列表失败: %s" % str(e))

    # 对于获取操作，直接返回响应数据
    if response_data:
        try:
            parsed_data = json.loads(response_data)
            # 检查是否有错误信息
            if 'errmsg' in parsed_data and parsed_data['errmsg']:
                module.fail_json(msg="获取配置文件列表失败", response=parsed_data)
            else:
                module.exit_json(changed=False, files=parsed_data)
        except Exception as e:
            module.fail_json(msg="解析响应失败: %s" % str(e))
    else:
        module.fail_json(msg="未收到有效响应")


def system_config_apply(module):
    """指定配置文件"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    file_name = module.params['file_name']

    # 检查必需参数
    if not file_name:
        module.fail_json(msg="指定配置文件需要提供file_name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.apply" % (
        ip, authkey)

    # 构造配置文件数据
    config_data = {
        "file_name": file_name
    }

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = json.dumps(config_data)
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            post_data = json.dumps(config_data)
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="指定配置文件失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "指定配置文件", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_config_del(module):
    """删除配置文件"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    file_name = module.params['file_name']

    # 检查必需参数
    if not file_name:
        module.fail_json(msg="删除配置文件需要提供file_name参数")

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.del" % (
        ip, authkey)

    # 构造配置文件数据
    config_data = {
        "file_name": file_name
    }

    # 初始化响应数据
    response_data = ""

    try:
        # 根据Python版本处理编码
        if sys.version_info[0] >= 3:
            # Python 3
            import urllib.request as urllib_request
            post_data = json.dumps(config_data)
            post_data = post_data.encode('utf-8')
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2
            import urllib2 as urllib_request
            post_data = json.dumps(config_data)
            req = urllib_request.Request(url, data=post_data, headers={
                                         'Content-Type': 'application/json'})
            response = urllib_request.urlopen(req)
            response_data = response.read()

    except Exception as e:
        module.fail_json(msg="删除配置文件失败: %s" % str(e))

    # 使用通用响应解析函数
    if response_data:
        success, result_dict = format_adc_response_for_ansible(
            response_data, "删除配置文件", True)
        if success:
            module.exit_json(**result_dict)
        else:
            module.fail_json(**result_dict)
    else:
        module.fail_json(msg="未收到有效响应")


def system_config_backup(module):
    """配置文件导出"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    name = module.params['name']
    dest_path = module.params.get('dest_path')

    if name:
        # 导出指定名称备份的配置
        url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.backup" % (
            ip, authkey)
        backup_data = {
            "name": name
        }

        # 初始化响应数据
        response_data = ""

        try:
            # 根据Python版本处理编码
            if sys.version_info[0] >= 3:
                # Python 3
                import urllib.request as urllib_request
                post_data = json.dumps(backup_data)
                post_data = post_data.encode('utf-8')
                req = urllib_request.Request(url, data=post_data, headers={
                                             'Content-Type': 'application/json'})
                response = urllib_request.urlopen(req)
                response_data = response.read().decode('utf-8')
            else:
                # Python 2
                import urllib2 as urllib_request
                post_data = json.dumps(backup_data)
                req = urllib_request.Request(url, data=post_data, headers={
                                             'Content-Type': 'application/json'})
                response = urllib_request.urlopen(req)
                response_data = response.read()

        except Exception as e:
            module.fail_json(msg="配置文件导出失败: %s" % str(e))

        # 使用通用响应解析函数
        if response_data:
            success, result_dict = format_adc_response_for_ansible(
                response_data, "配置文件导出", False)
            if success:
                module.exit_json(**result_dict)
            else:
                module.fail_json(**result_dict)
        else:
            module.fail_json(msg="未收到有效响应")
    else:
        # 下载当前设备的启动配置文件压缩包到本地
        if not dest_path:
            module.fail_json(msg="下载配置文件压缩包需要提供dest_path参数")

        url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.backup" % (
            ip, authkey)

        try:
            # 根据Python版本处理请求并下载文件
            if sys.version_info[0] >= 3:
                # Python 3
                import urllib.request as urllib_request
                response = urllib_request.urlopen(url)
                content = response.read()
            else:
                # Python 2
                import urllib2 as urllib_request
                response = urllib_request.urlopen(url)
                content = response.read()

            # 写入文件
            with open(dest_path, 'wb') as f:
                f.write(content)

            module.exit_json(changed=True,
                         file_path=dest_path,
                         file_size=len(content),
                         msg='配置文件压缩包已下载并保存到 %s' % dest_path)

        except Exception as e:
            module.fail_json(msg="配置文件压缩包下载失败: %s" % str(e))


def system_config_restore(module):
    """配置文件导入"""
    ip = module.params['ip']
    authkey = module.params['authkey']
    file_path = module.params.get('file_path')

    # 检查必要参数
    if not file_path:
        module.fail_json(msg="导入配置文件需要提供file_path参数")
    if not os.path.exists(file_path):
        module.fail_json(msg="配置文件不存在: %s" % file_path)

    # 构造请求URL
    url = "http://%s/adcapi/v2.0/?authkey=%s&action=system.config.restore" % (
        ip, authkey)

    # 读取配置文件
    try:
        with open(file_path, 'rb') as f:
            file_content = f.read()
    except Exception as e:
        module.fail_json(msg="读取配置文件失败: %s" % str(e))

    try:
        # 根据Python版本处理multipart/form-data上传
        if sys.version_info[0] >= 3:
            # Python 3 - 使用urllib处理multipart/form-data上传
            import urllib.request as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append('Content-Type: application/zip')
            body_parts.append('')
            body_parts.append('--%s--\r\n' % boundary)

            # 将body_parts转换为bytes并加上文件内容
            body_content = b''
            for part in body_parts:
                body_content += part.encode('utf-8') + b'\r\n'
            body_content += file_content
            body_content += b'\r\n--%s--\r\n' % boundary.encode('utf-8')

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read().decode('utf-8')
        else:
            # Python 2 - 使用urllib2处理multipart/form-data上传
            import urllib2 as urllib_request

            # 构建multipart/form-data请求
            boundary = '----WebKitFormBoundary7MA4YWxkTrZu0gW'

            # 准备表单数据
            body_parts = []
            body_parts.append('--%s' % boundary)
            body_parts.append(
                'Content-Disposition: form-data; name="file"; filename="%s"' % os.path.basename(file_path))
            body_parts.append('Content-Type: application/zip')
            body_parts.append('')
            body_parts.append('--%s--\r\n' % boundary)

            # 将body_parts转换为字符串并加上文件内容
            body_content = ''
            for part in body_parts:
                body_content += part + '\r\n'
            body_content += file_content
            body_content += '\r\n--%s--\r\n' % boundary

            req = urllib_request.Request(url, data=body_content, headers={
                'Content-Type': 'multipart/form-data; boundary=%s' % boundary,
                'Content-Length': str(len(body_content))
            })

            response = urllib_request.urlopen(req)
            response_data = response.read()

        # 使用通用响应解析函数
        if response_data:
            success, result_dict = format_adc_response_for_ansible(
                response_data, "配置文件导入", True)
            if success:
                result_dict['note'] = '导入后需要重新加载配置或者系统重启,使恢复的配置生效'
                module.exit_json(**result_dict)
            else:
                module.fail_json(**result_dict)
        else:
            module.fail_json(msg="未收到有效响应")

    except Exception as e:
        module.fail_json(msg="配置文件导入失败: %s" % str(e))


def main():
    # 定义模块参数
    module_args = dict(
        ip=dict(type='str', required=True),
        authkey=dict(type='str', required=True, no_log=True),
        action=dict(type='str', required=True, choices=[
            'system_config_add', 'system_config_list', 'system_config_apply', 'system_config_del',
            'system_config_backup', 'system_config_restore']),
        # 配置文件参数
        file_name=dict(type='str', required=False),
        description=dict(type='str', required=False),
        flag=dict(type='int', required=False),
        encrypt=dict(type='int', required=False),  # 是否加密配置文件
        overwrite=dict(type='int', required=False),  # 是否覆盖同名文件
        password=dict(type='str', required=False, no_log=True),
        name=dict(type='str', required=False),
        dest_path=dict(type='str', required=False),
        file_path=dict(type='str', required=False)
    )

    # 创建AnsibleModule实例
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # 根据action执行相应操作
    action = module.params['action']

    if action == 'system_config_add':
        system_config_add(module)
    elif action == 'system_config_list':
        system_config_list(module)
    elif action == 'system_config_apply':
        system_config_apply(module)
    elif action == 'system_config_del':
        system_config_del(module)
    elif action == 'system_config_backup':
        system_config_backup(module)
    elif action == 'system_config_restore':
        system_config_restore(module)


if __name__ == '__main__':
    main()
